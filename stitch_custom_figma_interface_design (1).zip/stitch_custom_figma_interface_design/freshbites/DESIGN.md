---
name: FreshBites
colors:
  surface: '#f9f9f6'
  surface-dim: '#dadad7'
  surface-bright: '#f9f9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f0'
  surface-container: '#eeeeeb'
  surface-container-high: '#e8e8e5'
  surface-container-highest: '#e2e3df'
  on-surface: '#1a1c1a'
  on-surface-variant: '#594139'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f1f1ee'
  outline: '#8d7168'
  outline-variant: '#e1bfb5'
  surface-tint: '#ab3500'
  primary: '#ab3500'
  on-primary: '#ffffff'
  primary-container: '#ff6b35'
  on-primary-container: '#5f1900'
  inverse-primary: '#ffb59d'
  secondary: '#625e58'
  on-secondary: '#ffffff'
  secondary-container: '#e5dfd7'
  on-secondary-container: '#66625c'
  tertiary: '#00677e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00a7cb'
  on-tertiary-container: '#003744'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59d'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#832600'
  secondary-fixed: '#e8e1da'
  secondary-fixed-dim: '#ccc6be'
  on-secondary-fixed: '#1e1b17'
  on-secondary-fixed-variant: '#4a4641'
  tertiary-fixed: '#b5ebff'
  tertiary-fixed-dim: '#59d5fb'
  on-tertiary-fixed: '#001f28'
  on-tertiary-fixed-variant: '#004e60'
  background: '#f9f9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e2e3df'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 0.5rem
  sm: 1rem
  md: 1.5rem
  lg: 2.5rem
  xl: 4rem
  container-max: 1280px
  gutter: 1.5rem
---

## Brand & Style

This design system is built on the philosophy of "The Modern Kitchen Companion." It bridges the gap between the high-energy urgency of food delivery and the refined, educational atmosphere of a culinary academy. The style is **Modern Editorial**, characterized by expansive whitespace, intentional typographic hierarchy, and a warm, organic color palette that mimics natural ingredients.

The brand persona is expert yet accessible—inspiring users to explore new flavors while providing the seamless utility needed for a quick meal. Every interface element is designed to evoke a sense of freshness and health, moving away from clinical minimalism toward a tactile, welcoming digital environment.

## Colors

The palette is anchored by **Vibrant Sunset Orange**, used strategically to drive action and stimulate appetite. It serves as the primary interactive color for buttons and critical brand moments. 

**Soft Cream** replaces pure white as the primary background surface to create an organic, parchment-like feel that aligns with a cooking school's premium heritage. **Deep Forest Green** acts as a sophisticated accent, reserved for health-conscious callouts, organic tags, and sustainability markers. Typography is rendered in **Slate Grey** to ensure high legibility without the harshness of pure black, maintaining the system's warm, contemporary character.

## Typography

This design system utilizes a high-contrast typographic pairing to balance tradition and modernity. **Playfair Display** provides a sophisticated, editorial "Cooking School" feel for headlines, making recipes and class titles feel like a premium publication. 

For utility and body text, **Montserrat** offers a clean, geometric sans-serif aesthetic that ensures legibility during fast-paced browsing or following complex cooking instructions. The system uses generous line-heights to improve readability and a tight letter-spacing for large display headers to maintain a contemporary, punchy appearance.

## Layout & Spacing

The layout follows a **12-column fluid grid** for desktop and a **4-column grid** for mobile devices. It prioritizes "Food-First" information architecture, where high-quality photography takes precedence. 

Vertical rhythm is established using a base-8 spacing scale. On desktop, large internal margins (80px–120px) create an airy, premium feel. On mobile, side margins are reduced to 20px to maximize the visual impact of food imagery. Layout containers use dynamic padding to ensure that content never feels cramped, maintaining the "easy to use" brand promise even in data-heavy recipe lists.

## Elevation & Depth

To maintain a soft and friendly aesthetic, the design system avoids heavy, dark shadows. Instead, it utilizes **Ambient Tinted Shadows**. Elevations are created using low-opacity shadows that incorporate a fraction of the primary orange or deep green hue, making the "float" feel more natural to the warm background.

Interactive elements like cards and buttons use a two-tiered elevation system:
1.  **Resting State:** A subtle, diffused shadow (12% opacity) to provide a hint of depth.
2.  **Hover/Active State:** A slightly more pronounced shadow with a 4px vertical offset, indicating tangibility and "pressability."
3.  **Tonal Layers:** Occasional use of "Soft Cream" against white backgrounds creates a tiered surface effect without the need for shadows in more information-dense areas.

## Shapes

The shape language is defined by high-radius **Rounded Geometry**. Standard containers, such as dish cards and promotional banners, utilize a 24px corner radius to feel approachable and modern. 

Buttons and input fields follow a consistent 16px radius. This "friendly" rounding is applied to all decorative elements, including image containers, to ensure the UI feels soft and avoids the clinical sharpness of traditional enterprise apps.

## Components

### Buttons
Primary action buttons are solid Sunset Orange with white or Slate Grey text. They feature a generous 16px vertical padding. Secondary buttons use a Deep Forest Green outline with a subtle cream fill.

### Cards
Cards are the primary content vehicle. They feature 24px rounded corners, a subtle 1px border in a darker cream shade, and high-quality, warm-lit photography that bleeds to the top edge. Information is presented with ample internal padding (24px).

### Chips & Badges
Used for dietary labels (e.g., "Vegan," "Gluten-Free"). These use the Deep Forest Green background with white Montserrat text in a pill shape (100px radius) to signify health and freshness.

### Inputs
Search bars and form fields use a light cream background with a subtle Slate Grey border. On focus, the border transitions to Sunset Orange to provide clear visual feedback.

### Recipe Progress Indicators
A unique component for the cooking school—stepped progress bars using Sunset Orange to track class completion, utilizing rounded segments to match the overall shape language.